// ========== MÓDULO MEJORAS DEL BARRIO ==========

VV.improvements = {
    // Cargar mejoras
    load() {
        const container = document.getElementById('improvements-list');
        
        // Filtrar solo mejoras del mismo barrio
        const neighborhoodImprovements = VV.data.improvements.filter(i => 
            !i.neighborhood || i.neighborhood === VV.data.neighborhood
        );
        
        if (neighborhoodImprovements.length === 0) {
            container.innerHTML = `
                <div style="grid-column: 1/-1; text-align: center; padding: 3rem; color: var(--gray-600);">
                    <i class="fas fa-tools" style="font-size: 3rem; margin-bottom: 1rem; opacity: 0.5;"></i>
                    <h3>No hay mejoras propuestas</h3>
                    <p>Sé el primero en proponer una mejora</p>
                </div>
            `;
            return;
        }
        
        container.innerHTML = neighborhoodImprovements.map(imp => `
            <div class="improvement-card">
                <div class="card-header">
                    <h3>${imp.title}</h3>
                    <div style="display: flex; gap: 0.5rem;">
                        <span class="badge status-${imp.status.toLowerCase().replace(' ', '-')}">${imp.status}</span>
                        <span class="badge priority-${imp.priority.toLowerCase()}">${imp.priority}</span>
                    </div>
                </div>
                <p style="color: var(--gray-700); margin: 0.5rem 0;">${imp.description}</p>
                <div class="card-footer">
                    <span style="color: var(--gray-600);"><i class="fas fa-tag"></i> ${imp.category}</span>
                    <button class="vote-btn" onclick="VV.improvements.vote('${imp.id}')">
                        <i class="fas fa-thumbs-up"></i> ${imp.votes}
                    </button>
                </div>
            </div>
        `).join('');
    },
    
    // Mostrar formulario
    showForm(improvementId = null) {
        window.scrollTo({ top: 0, behavior: 'smooth' });
        
        const improvement = improvementId ? VV.data.improvements.find(i => i.id === improvementId) : null;
        const isEdit = improvement !== null;
        
        let overlay = document.getElementById('improvement-form-overlay');
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.id = 'improvement-form-overlay';
            overlay.className = 'modal-overlay';
            document.body.appendChild(overlay);
        }
        
        overlay.innerHTML = `
            <div class="modal-form">
                <h3><i class="fas fa-${isEdit ? 'edit' : 'lightbulb'}"></i> ${isEdit ? 'Editar' : 'Proponer'} Mejora</h3>
                <form id="improvement-form">
                    <div class="form-group">
                        <label>Título *</label>
                        <input type="text" id="improvement-title" value="${improvement?.title || ''}" required>
                    </div>
                    <div class="form-group">
                        <label>Descripción *</label>
                        <textarea id="improvement-description" rows="4" required>${improvement?.description || ''}</textarea>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Categoría *</label>
                            <select id="improvement-category" required>
                                <option value="">Seleccionar</option>
                                <option value="Infraestructura" ${improvement?.category === 'Infraestructura' ? 'selected' : ''}>Infraestructura</option>
                                <option value="Seguridad" ${improvement?.category === 'Seguridad' ? 'selected' : ''}>Seguridad</option>
                                <option value="Limpieza" ${improvement?.category === 'Limpieza' ? 'selected' : ''}>Limpieza</option>
                                <option value="Espacios Verdes" ${improvement?.category === 'Espacios Verdes' ? 'selected' : ''}>Espacios Verdes</option>
                                <option value="Otros" ${improvement?.category === 'Otros' ? 'selected' : ''}>Otros</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Prioridad *</label>
                            <select id="improvement-priority" required>
                                <option value="">Seleccionar</option>
                                <option value="Alta" ${improvement?.priority === 'Alta' ? 'selected' : ''}>Alta</option>
                                <option value="Media" ${improvement?.priority === 'Media' ? 'selected' : ''}>Media</option>
                                <option value="Baja" ${improvement?.priority === 'Baja' ? 'selected' : ''}>Baja</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="button" class="btn-cancel" onclick="VV.improvements.closeForm()">Cancelar</button>
                        <button type="submit" class="btn-save">
                            <i class="fas fa-save"></i> ${isEdit ? 'Actualizar' : 'Guardar'}
                        </button>
                    </div>
                </form>
            </div>
        `;
        
        overlay.classList.add('active');
        
        document.getElementById('improvement-form').onsubmit = (e) => {
            e.preventDefault();
            VV.improvements.save(improvement);
        };
        
        overlay.onclick = (e) => {
            if (e.target === overlay) VV.improvements.closeForm();
        };
    },
    
    // Cerrar formulario
    closeForm() {
        const overlay = document.getElementById('improvement-form-overlay');
        if (overlay) overlay.classList.remove('active');
    },
    
    // Guardar mejora
    save(existing) {
        const formData = {
            title: document.getElementById('improvement-title').value.trim(),
            description: document.getElementById('improvement-description').value.trim(),
            category: document.getElementById('improvement-category').value,
            priority: document.getElementById('improvement-priority').value
        };
        
        if (!formData.title || !formData.description || !formData.category || !formData.priority) {
            alert('Completa todos los campos');
            return;
        }
        
        if (existing) {
            const index = VV.data.improvements.findIndex(i => i.id === existing.id);
            VV.data.improvements[index] = { ...existing, ...formData };
        } else {
            VV.data.improvements.push({
                id: VV.utils.generateId(),
                ...formData,
                status: 'Pendiente',
                votes: 0,
                userId: VV.data.user.id,
                userName: VV.data.user.name,
                neighborhood: VV.data.neighborhood,
                createdAt: new Date().toISOString()
            });
        }
        
        // Guardar en localStorage
        localStorage.setItem('vecinosVirtuales_improvements', JSON.stringify(VV.data.improvements));
        
        VV.improvements.closeForm();
        VV.improvements.load();
        VV.utils.showSuccess(existing ? 'Mejora actualizada' : 'Mejora propuesta');
    },
    
    // Votar mejora
    vote(improvementId) {
        const improvement = VV.data.improvements.find(i => i.id === improvementId);
        if (improvement) {
            improvement.votes += 1;
            
            // Guardar en localStorage
            localStorage.setItem('vecinosVirtuales_improvements', JSON.stringify(VV.data.improvements));
            
            VV.improvements.load();
        }
    }
};

console.log('✅ Módulo IMPROVEMENTS cargado');
