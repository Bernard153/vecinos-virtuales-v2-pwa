// ========== MÓDULO BANNER - MODO REPLEGADO Y DESPLEGADO ==========

VV.banner = {
    expanded: false,
    currentBanners: [],
    rotationInterval: null,
    
    // Inicializar banner
    init() {
        const container = document.getElementById('banner-container');
        
        // Filtrar anunciantes activos y que correspondan al barrio actual
        VV.banner.currentBanners = VV.data.sponsors.filter(s => {
            if (!s.active) return false;
            
            // Si no tiene barrios definidos o es 'all', mostrar en todos
            if (!s.neighborhoods || s.neighborhoods === 'all') return true;
            
            // Si tiene barrios específicos, verificar si el barrio actual está incluido
            if (Array.isArray(s.neighborhoods)) {
                return s.neighborhoods.includes(VV.data.neighborhood);
            }
            
            return false;
        });
        
        // Agregar botón de toggle
        VV.banner.addToggleButton();
        
        // Mostrar en modo replegado por defecto
        VV.banner.showCollapsed();
    },
    
    // Agregar botón de toggle
    addToggleButton() {
        let toggleBtn = document.getElementById('banner-toggle-btn');
        if (!toggleBtn) {
            toggleBtn = document.createElement('button');
            toggleBtn.id = 'banner-toggle-btn';
            toggleBtn.style.cssText = `
                position: fixed;
                bottom: 90px;
                right: 20px;
                background: var(--primary-purple);
                color: white;
                border: none;
                border-radius: 50%;
                width: 50px;
                height: 50px;
                font-size: 1.2rem;
                cursor: pointer;
                box-shadow: 0 4px 12px rgba(0,0,0,0.3);
                z-index: 999;
                transition: all 0.3s;
            `;
            toggleBtn.innerHTML = '<i class="fas fa-th"></i>';
            toggleBtn.onclick = () => VV.banner.toggle();
            document.body.appendChild(toggleBtn);
        }
    },
    
    // Toggle entre modos
    toggle() {
        VV.banner.expanded = !VV.banner.expanded;
        const btn = document.getElementById('banner-toggle-btn');
        
        if (VV.banner.expanded) {
            btn.innerHTML = '<i class="fas fa-times"></i>';
            VV.banner.showExpanded();
        } else {
            btn.innerHTML = '<i class="fas fa-th"></i>';
            VV.banner.showCollapsed();
        }
    },
    
    // Modo replegado (3 banners aleatorios)
    showCollapsed() {
        const container = document.getElementById('banner-container');
        container.style.cssText = 'display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem; padding: 1rem; background: white; border-top: 2px solid var(--gray-200);';
        
        if (VV.banner.currentBanners.length === 0) {
            container.innerHTML = `
                <div class="banner-slide" style="opacity: 0.5;">
                    <div class="banner-logo">🏪</div>
                    <div>
                        <div class="banner-title">Tu Anuncio Aquí</div>
                        <div class="banner-description">Espacio disponible</div>
                    </div>
                </div>
                <div class="banner-slide" style="opacity: 0.5;">
                    <div class="banner-logo">💼</div>
                    <div>
                        <div class="banner-title">Publicita tu Negocio</div>
                        <div class="banner-description">Contacta al admin</div>
                    </div>
                </div>
                <div class="banner-slide" style="opacity: 0.5;">
                    <div class="banner-logo">🎯</div>
                    <div>
                        <div class="banner-title">Llega a tu Barrio</div>
                        <div class="banner-description">Sé Anunciante</div>
                    </div>
                </div>
            `;
            return;
        }
        
        // Seleccionar 3 banners aleatorios
        const shuffled = [...VV.banner.currentBanners].sort(() => Math.random() - 0.5);
        const bannersToShow = shuffled.slice(0, 3);
        
        // Rellenar con placeholders si hay menos de 3
        while (bannersToShow.length < 3) {
            bannersToShow.push({
                logo: '🏪',
                name: 'Espacio Disponible',
                description: 'Tu anuncio aquí',
                tier: 'silver',
                id: 'placeholder-' + bannersToShow.length
            });
        }
        
        container.innerHTML = bannersToShow.map(banner => `
            <div class="banner-slide ${banner.tier}" onclick="VV.banner.click('${banner.id}')">
                ${banner.imageUrl ? 
                    `<div class="banner-image" style="background-image: url('${banner.imageUrl}');"></div>` :
                    `<div class="banner-logo">${banner.logo}</div>`
                }
                <div>
                    <div class="banner-title">${banner.name}</div>
                    <div class="banner-description">${banner.description}</div>
                </div>
            </div>
        `).join('');
        
        // Rotar banners cada 5 segundos
        VV.banner.startRotation();
    },
    
    // Modo desplegado (todos los anunciantes en formato folleto)
    showExpanded() {
        VV.banner.stopRotation();
        
        const container = document.getElementById('banner-container');
        container.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.95);
            z-index: 998;
            overflow-y: auto;
            padding: 2rem;
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 1.5rem;
            align-content: start;
        `;
        
        if (VV.banner.currentBanners.length === 0) {
            container.innerHTML = `
                <div style="grid-column: 1/-1; text-align: center; color: white; padding: 3rem;">
                    <i class="fas fa-bullhorn" style="font-size: 4rem; margin-bottom: 1rem; opacity: 0.5;"></i>
                    <h2>No hay anunciantes en tu barrio</h2>
                    <p>Sé el primero en anunciarte</p>
                </div>
            `;
            return;
        }
        
        container.innerHTML = VV.banner.currentBanners.map(banner => `
            <div class="banner-card-expanded ${banner.tier}" onclick="VV.banner.click('${banner.id}')">
                ${banner.imageUrl ? 
                    `<div class="banner-card-image" style="background-image: url('${banner.imageUrl}'); height: 200px; background-size: cover; background-position: center; border-radius: 12px 12px 0 0;"></div>` :
                    `<div class="banner-card-logo">${banner.logo}</div>`
                }
                <div class="banner-card-content">
                    <div class="banner-card-tier">${banner.tier.toUpperCase()}</div>
                    <h3>${banner.name}</h3>
                    <p>${banner.description}</p>
                    <div class="banner-card-info">
                        <p><i class="fas fa-phone"></i> ${banner.contact}</p>
                        ${banner.website ? `<p><i class="fas fa-globe"></i> ${banner.website}</p>` : ''}
                    </div>
                    <div class="banner-card-stats">
                        <span><i class="fas fa-eye"></i> ${banner.views || 0} vistas</span>
                        <span><i class="fas fa-mouse-pointer"></i> ${banner.clicks || 0} clics</span>
                    </div>
                </div>
            </div>
        `).join('');
    },
    
    // Iniciar rotación de banners
    startRotation() {
        VV.banner.stopRotation();
        VV.banner.rotationInterval = setInterval(() => {
            if (!VV.banner.expanded) {
                VV.banner.showCollapsed();
            }
        }, 5000);
    },
    
    // Detener rotación
    stopRotation() {
        if (VV.banner.rotationInterval) {
            clearInterval(VV.banner.rotationInterval);
            VV.banner.rotationInterval = null;
        }
    },
    
    // Click en banner
    click(sponsorId) {
        if (sponsorId.startsWith('placeholder')) return;
        
        const sponsor = VV.data.sponsors.find(s => s.id === sponsorId);
        if (sponsor) {
            sponsor.clicks += 1;
            sponsor.views += 1;
            if (sponsor.website) {
                window.open(sponsor.website, '_blank');
            }
        }
    }
};

console.log('✅ Módulo BANNER cargado');
